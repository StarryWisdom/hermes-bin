--run on each time first connected to a server
setShipNum(0);
setShipType("TSN Sabre",19,0);
setShipNum(1);
setShipType("TSN Horizon",20,0.125);
setShipNum(2);
setShipType("TSN Viper",21,0.25);
setShipNum(3);
setShipType("TSN Lancer",17,0.641);
setShipNum(4);
setShipType("TSN Hunter",0,0.5);
setShipNum(5);
setShipType("TSN Osiris",21,0.675);
setShipNum(6);
setShipType("TSN Stalker",0,0.75);
setShipNum(7);
setShipType("TSN Eagle",0,0.875);